/**
 * Class admin
 *
 * @author Bryan Oliver
 * @version 24.5.2021
 */

public class admin {
    public static void main(String[] args) {
        GUI wingui = new GUI();

    }
}
