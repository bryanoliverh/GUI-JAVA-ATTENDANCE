/**
 * Exception Class ExceptionBlankInput
 *
 * @author Bryan Oliver
 * @version 24.5.2021
 */

public class ExceptionBlankInput extends Exception{
    public String toString(){
        return "Please fill your input\n";
    }
}